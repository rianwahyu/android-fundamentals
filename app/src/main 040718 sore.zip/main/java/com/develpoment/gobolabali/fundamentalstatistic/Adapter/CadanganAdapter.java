package com.develpoment.gobolabali.fundamentalstatistic.Adapter;

import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import com.develpoment.gobolabali.fundamentalstatistic.Database.DatabaseHelper;
import com.develpoment.gobolabali.fundamentalstatistic.Games.GameActivity;
import com.develpoment.gobolabali.fundamentalstatistic.Helpers.ItemClickListener;
import com.develpoment.gobolabali.fundamentalstatistic.Model.DataPlayer;
import com.develpoment.gobolabali.fundamentalstatistic.Model.DataPlayerMatch;
import com.develpoment.gobolabali.fundamentalstatistic.R;

import java.util.ArrayList;
import java.util.List;

public class CadanganAdapter extends RecyclerView.Adapter<CadanganAdapter.PlayerHolder> {
    private ClickListener mListener;
    private List<DataPlayerMatch> mainInfo = new ArrayList();


//    DBConfig myDatabase;

    public interface ClickListener {
        void onClick(int i);
    }

    public class PlayerHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        Button btnCadangan;
        private ItemClickListener clickListener;
        TextView txtNickname;

        public PlayerHolder(View itemView) {
            super(itemView);
            txtNickname = (TextView) itemView.findViewById(R.id.txtNickname);
            btnCadangan = (Button) itemView.findViewById(R.id.btnCadangan);
            itemView.setOnClickListener(this);
        }

        public void onClick(View view) {
            mListener.onClick(getLayoutPosition());
        }
    }

    public CadanganAdapter(ClickListener listener) {
        mListener = listener;
    }

    public void addItem(DataPlayerMatch item) {
        mainInfo.add(item);
        notifyDataSetChanged();
    }

    public void clearItem() {
        mainInfo.clear();
        notifyDataSetChanged();
    }

    public DataPlayerMatch getSelectedItem(int position) {
        return (DataPlayerMatch) mainInfo.get(position);
    }

    public PlayerHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        return new PlayerHolder(LayoutInflater.from(parent.getContext()).inflate(R.layout.cadangan_raw, parent, false));
    }


    public void onBindViewHolder(PlayerHolder holder, int position) {

        holder.txtNickname.setText(((DataPlayerMatch) mainInfo.get(position)).getNickname());
        holder.btnCadangan.setText(((DataPlayerMatch) mainInfo.get(position)).getNopunggun());
        if (((DataPlayerMatch) mainInfo.get(position)).getStatus().equals("0")) {
            holder.btnCadangan.setBackgroundResource(R.drawable.touch_green_dark);
        }
    }

    public int getItemCount() {
        return mainInfo.size();
    }
}
