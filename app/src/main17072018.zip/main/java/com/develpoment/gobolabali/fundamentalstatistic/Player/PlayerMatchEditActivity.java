package com.develpoment.gobolabali.fundamentalstatistic.Player;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;

import com.develpoment.gobolabali.fundamentalstatistic.Database.DatabaseHelper;
import com.develpoment.gobolabali.fundamentalstatistic.Match.MatchPlayerListActivity;
import com.develpoment.gobolabali.fundamentalstatistic.R;

import org.apache.commons.cli.HelpFormatter;

import java.util.ArrayList;
import java.util.List;

public class PlayerMatchEditActivity extends AppCompatActivity {

    String idmatch, idplayer, idteam;

    Spinner spinpos, spinstat;
    EditText etnopunggung;
    Button submit;

    List<SpinnerData> list;
    ArrayAdapter<SpinnerData> listAdapter;
    ArrayAdapter<SpinnerData> listStatusAdapter;
    List<SpinnerData> statusList;
    DatabaseHelper db =  new DatabaseHelper(this);

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_player_match_edit);

        idmatch = getIntent().getStringExtra("idmatch");
        idplayer = getIntent().getStringExtra("idplayer");
        idteam = getIntent().getStringExtra("idteam");

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbarPlayer);
        toolbar.setTitle("Player Match Edit");
        toolbar.setNavigationIcon(R.drawable.ic_back_white);
        toolbar.setTitleTextColor(Color.WHITE);
        setSupportActionBar(toolbar);

        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(getApplicationContext(), MatchPlayerListActivity.class);
                startActivity(i);
                finish();
            }
        });

//        initRecylerView();
        spinpos = (Spinner) findViewById(R.id.spPosition);
        spinstat = (Spinner) findViewById(R.id.spStatus);
        etnopunggung = (EditText) findViewById(R.id.et_noPunggung);
        submit = (Button) findViewById(R.id.buttonSubmitPlayer);

        setupPosition();
        //setupEdit();

    }

/*    private void setupEdit() {
//        etnopunggung.setText(no);
        if (this.player.getStatus() != null) {
            spinstat.setSelection(getIndexStatus(player.getStatus()));
        }
        if (this.player.getPosition() != null) {
            spinpos.setSelection(getIndexPosition(player.getPosition()));
        }
    }*/

    private void setupPosition() {
        list = new ArrayList();
        list.add(new SpinnerData(HelpFormatter.DEFAULT_OPT_PREFIX, " "));
        list.add(new SpinnerData("Defender (DF)", "21"));
        list.add(new SpinnerData("Midfielder (MF)", "31"));
        list.add(new SpinnerData("Forward (FD)", "41"));
        statusList = new ArrayList();
        statusList.add(new SpinnerData("CADANGAN", "0"));
        statusList.add(new SpinnerData("INTI", "1"));
    }

    private class SpinnerData {
        public String string;
        public Object tag;

        public SpinnerData(String stringPart, Object tagPart) {
            this.string = stringPart;
            this.tag = tagPart;
        }

        @Override
        public String toString() {
            return string;
        }
    }
}
