package com.develpoment.gobolabali.fundamentalstatistic.Fragment;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.TextView;

import com.develpoment.gobolabali.fundamentalstatistic.Adapter.AdapterPlayer;
import com.develpoment.gobolabali.fundamentalstatistic.Adapter.PlayerMatchAdapter;
import com.develpoment.gobolabali.fundamentalstatistic.Database.DatabaseHelper;
import com.develpoment.gobolabali.fundamentalstatistic.Model.DataPlayer;
import com.develpoment.gobolabali.fundamentalstatistic.Model.DataPlayerMatch;
import com.develpoment.gobolabali.fundamentalstatistic.Model.Player;
import com.develpoment.gobolabali.fundamentalstatistic.Player.PlayerActivity;
import com.develpoment.gobolabali.fundamentalstatistic.Player.PlayerMatchEditActivity;
import com.develpoment.gobolabali.fundamentalstatistic.R;
import com.google.gson.Gson;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class FragmentPlayer2 extends Fragment implements PlayerMatchAdapter.ClickListener {

    String idteam, idtournament, idmatch, poss;
    private Bundle bundle1;
    RecyclerView rv;

    private LinearLayoutManager layoutManager;
//    private AdapterPlayerList adapterPlayer;
    private PlayerMatchAdapter playerMatchAdapter;
    private DatabaseHelper db = new DatabaseHelper(getActivity());
    private List<DataPlayerMatch> teamList = new ArrayList<DataPlayerMatch>();

    public FragmentPlayer2() {
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        bundle1 = this.getArguments();
        idteam = bundle1.getString("idteam");
        idtournament = bundle1.getString("idtournament");
        idmatch = bundle1.getString("idmatch");
        poss = bundle1.getString("pos");
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View frag = inflater.inflate(R.layout.fragment_player2,container,false);

        rv = (RecyclerView) frag.findViewById(R.id.listfragteam2);
        db = new DatabaseHelper(getActivity());
        playerMatchAdapter = new PlayerMatchAdapter(this, poss);
        getData();
        setMainRecyclerView();
        return frag;
    }


    public void getData() {
        List<Player> data = new ArrayList();
        Cursor c = db.getPlayerByMatchTeam(idteam, idmatch);
        if (c != null) {
            while (c.moveToNext()) {
                String nameText = c.getString(c.getColumnIndex("fullname"));
                String idText = c.getString(c.getColumnIndex("idplayer"));
                String playerNumberText = c.getString(c.getColumnIndex("nopunggung"));
//                String accountNumberText = c.getString(c.getColumnIndex("account_number"));
                String nicknameText = c.getString(c.getColumnIndex("nickname"));
                String statusText = c.getString(c.getColumnIndex("status"));
                String positionText = c.getString(c.getColumnIndex("posnomor"));
                Player player = new Player();
                player.setName(nameText);
                player.setId(idText);
                player.setPlayer_number(playerNumberText);
//                player.setAccount_number(accountNumberText);
                player.setNickname(nicknameText);
                player.setStatus(statusText);
                player.setPosition(positionText);
                playerMatchAdapter.addItem(player);
                Log.e("TAG", "POS:" + positionText);


            }
        }
    }

    public void setMainRecyclerView() {
        rv.setHasFixedSize(true);
        rv.setLayoutManager(new LinearLayoutManager(getActivity()));
        rv.addItemDecoration(new DividerItemDecoration(getActivity(), DividerItemDecoration.VERTICAL));
        rv.setAdapter(playerMatchAdapter);
    }


    @Override
    public void onClick(int i) {

    }
}
