package com.develpoment.gobolabali.fundamentalstatistic.About;

import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.graphics.Color;
import android.support.design.widget.CollapsingToolbarLayout;
import android.support.v4.view.ViewCompat;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.webkit.WebView;
import android.widget.Button;

import com.develpoment.gobolabali.fundamentalstatistic.Main.MainActivity;
import com.develpoment.gobolabali.fundamentalstatistic.R;

public class AboutActivity extends AppCompatActivity {

    private static final String EXTRA_IMAGE = "ok";
    CollapsingToolbarLayout collapsingAbout ;
    Toolbar toolbarAbout ;
    WebView wvabout ;
    @Override
    public void supportInvalidateOptionsMenu() {
        super.supportInvalidateOptionsMenu();
        setContentView(R.layout.activity_about);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);

        wvabout = (WebView) findViewById(R.id.webAbout);
        wvabout.loadUrl("file:///android_asset/about.html");

        ViewCompat.setTransitionName(findViewById(R.id.appBarAbout),EXTRA_IMAGE);

        collapsingAbout = (CollapsingToolbarLayout) findViewById(R.id.collapsingToolbarAbout);
        collapsingAbout.setTitle("About Us");
        collapsingAbout.setExpandedTitleColor(Color.TRANSPARENT);
        collapsingAbout.setCollapsedTitleTextColor(Color.WHITE);

        toolbarAbout = (Toolbar) findViewById(R.id.toolbarAbout);
        toolbarAbout.setNavigationIcon(R.drawable.ic_back_white);
        setSupportActionBar(toolbarAbout);

        toolbarAbout.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(AboutActivity.this, MainActivity.class));
                finish();
            }
        });
    }

    @Override
    public void onBackPressed() {
        startActivity(new Intent(AboutActivity.this, MainActivity.class));
        finish();
    }
}
