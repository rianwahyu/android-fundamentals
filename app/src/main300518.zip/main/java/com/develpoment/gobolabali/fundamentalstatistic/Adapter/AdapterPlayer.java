package com.develpoment.gobolabali.fundamentalstatistic.Adapter;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.develpoment.gobolabali.fundamentalstatistic.Database.DatabaseHelper;
import com.develpoment.gobolabali.fundamentalstatistic.Model.DataPlayer;
import com.develpoment.gobolabali.fundamentalstatistic.Model.DataTeam;
import com.develpoment.gobolabali.fundamentalstatistic.Player.PlayerActivity;
import com.develpoment.gobolabali.fundamentalstatistic.R;
import com.develpoment.gobolabali.fundamentalstatistic.Team.EditTeamActivity;
import com.shashank.sony.fancydialoglib.Animation;
import com.shashank.sony.fancydialoglib.FancyAlertDialogListener;

import java.util.List;

public class AdapterPlayer extends RecyclerView.Adapter<AdapterPlayer.AdapterTeamViewHolder> {

    private List<DataPlayer> playerList;
    private Activity activity;

    DatabaseHelper db;

    public AdapterPlayer(Activity activity, List<DataPlayer> playerList) {
        this.activity = activity;
        this.playerList = playerList;
    }

    @Override
    public AdapterPlayer.AdapterTeamViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.adapter_team, parent, false);
        AdapterTeamViewHolder adapterTeamViewHolder = new AdapterTeamViewHolder(view);
        return adapterTeamViewHolder;
    }

    @Override
    public void onBindViewHolder(AdapterPlayer.AdapterTeamViewHolder holder, int position) {
        db = new DatabaseHelper(activity);
        final DataPlayer player = playerList.get(position);

    }

    @Override
    public int getItemCount() {
        return playerList.size();
    }

    public class AdapterTeamViewHolder extends RecyclerView.ViewHolder {
        TextView txtnoPunggung, txtNickName, txtPosisi;
        public AdapterTeamViewHolder(View itemView) {
            super(itemView);

            txtnoPunggung = (TextView) itemView.findViewById(R.id.textNickNamePlayer);
            txtNickName = (TextView) itemView.findViewById(R.id.textNickNamePlayer);
            txtPosisi = (TextView) itemView.findViewById(R.id.textPosisiPlayer);

        }
    }

    @Override
    public void onAttachedToRecyclerView(RecyclerView recyclerView) {
        super.onAttachedToRecyclerView(recyclerView);
    }
}
