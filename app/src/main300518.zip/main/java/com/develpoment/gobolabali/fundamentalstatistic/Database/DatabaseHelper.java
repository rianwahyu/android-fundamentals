package com.develpoment.gobolabali.fundamentalstatistic.Database;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;
import android.widget.ListView;

import com.develpoment.gobolabali.fundamentalstatistic.Model.DataTeam;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String LOG ="DatabaseHelper";

    private static final  int DATABASE_VERSION = 1;

    private static final String DATABASE_NAME = "fundamentalStatistic";

    private static final String TABLE_TEAM= "team";

    private static final String TABLE_PLAYER = "player";

    private static final String ID_TEAM = "id";
    private static final String NAMA_TEAM = "nama";

    private static final String ID_PLAYER = "id";
    private static final String FULL_NAME_PLAYER = "fullname";
    private static final String NICK_NAME_PLAYER = "nickname";
    private static final String POSISI_PLAYER = "posisi";
    private static final String BIRTH_PLAYER = "birth";
    private static final String NO_PUNGGUNG_PLAYER = "nopunggung";
    private static final String KEY_ID_TEAM_PLAYER = "idteam";



    private static final String CREATE_TABLE_TEAM = "CREATE TABLE "
            + TABLE_TEAM + "(" +ID_TEAM + " INTEGER PRIMARY KEY AUTOINCREMENT,"
            + NAMA_TEAM + " TEXT " + ")";

    private static final String CREATE_TABLE_PLAYER = "CREATE TABLE "
            + TABLE_PLAYER + "(" + ID_PLAYER + " INTEGER PRIMARY KEY AUTOINCREMENT,"
            + FULL_NAME_PLAYER + " TEXT, "
            + NICK_NAME_PLAYER + " TEXT, "
            + POSISI_PLAYER + " TEXT, "
            + BIRTH_PLAYER + " TEXT, "
            + NO_PUNGGUNG_PLAYER + " TEXT,"
            + KEY_ID_TEAM_PLAYER + " INTEGER " + ")";

    Context context;

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
//        this.context = context;
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_TABLE_TEAM);
        db.execSQL(CREATE_TABLE_PLAYER);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL(" DROP TABLE IF EXISTS " + TABLE_TEAM);
        db.execSQL(" DROP TABLE IF EXISTS " + TABLE_PLAYER);
    }






    // -- QUERY CRUD TABEL TEAM

    public ArrayList<HashMap<String,String>> getAllTeam(){
        ArrayList<HashMap<String,String>> teamList;
        teamList = new ArrayList<HashMap<String, String>>();
        String selectQuery = "SELECT * FROM " +TABLE_TEAM;
        SQLiteDatabase database = this.getWritableDatabase();
        Cursor cursor = database.rawQuery(selectQuery,null);
        if (cursor.moveToFirst()) {
            do {
                HashMap<String, String> map = new HashMap<String, String>();
                map.put(ID_TEAM, cursor.getString(0));
                map.put(NAMA_TEAM, cursor.getString(1));
                teamList.add(map);
            }while (cursor.moveToNext());

        }
        Log.e("select sqlite " ,"" +teamList);

        database.close();
        return teamList;
    }

    public List<DataTeam> getTeam (){
        List<DataTeam> teamList = new ArrayList<>();
        String selectQuery = "SELECT * FROM " + TABLE_TEAM;

        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);

        if (cursor.moveToFirst()){
            DataTeam tem = new DataTeam();
            tem.setId(cursor.getString(cursor.getColumnIndex("id")));
            tem.setNama(cursor.getString(cursor.getColumnIndex("nama")));
            teamList.add(tem);
        }while (cursor.moveToNext());
        return teamList;
    }

    public void insertTeam(String nama) {
        SQLiteDatabase database = this.getWritableDatabase();
        String queryValues = " INSERT INTO " + TABLE_TEAM + "(nama)" +
                "VALUES ('" + nama + "')";
        Log.e("insert sqlite" ,"" + queryValues);
        database.execSQL(queryValues);
        database.close();
    }

    public void updateTeam(int id, String nama) {
        SQLiteDatabase database = this.getWritableDatabase();

        String updateQuery = " UPDATE " +TABLE_TEAM+ " SET "
                + NAMA_TEAM + "='" + nama + "'"
                + " WHERE " + ID_TEAM + "=" + "'" + id + "'";
        Log.e("update sqlite" , updateQuery);

        database.execSQL(updateQuery);
        database.close();
    }

    public void delete(int id){
        SQLiteDatabase database = this.getWritableDatabase();

        String deleteQuery = " DELETE FROM " + TABLE_TEAM + " WHERE " + ID_TEAM +
                "=" + "'" + id + "'";
        Log.e("delete" ,deleteQuery);
        database.execSQL(deleteQuery);
        database.close();
    }
    // -- AKHIR CRUD TABEL TEAM -- \\


    // -- QUERY CRUD TABEL PLAYER -- \\
    public ArrayList<HashMap<String,String>> getAllPlayer (){

        ArrayList<HashMap<String,String>>  playerList;
        playerList = new ArrayList<>();
        String selectQuery = " SELECT * FROM " + TABLE_PLAYER;
        SQLiteDatabase database = this.getWritableDatabase();
        Cursor cursor = database.rawQuery(selectQuery,null);
        if (cursor.moveToFirst()) {
            do {
                HashMap<String, String> map = new HashMap<String, String>();
                map.put(ID_PLAYER, cursor.getString(0));
                map.put(FULL_NAME_PLAYER, cursor.getString(1));
                map.put(NICK_NAME_PLAYER, cursor.getString(2));
                map.put(POSISI_PLAYER, cursor.getString(3));
                map.put(BIRTH_PLAYER, cursor.getString(4));
                map.put(NO_PUNGGUNG_PLAYER, cursor.getString(5));
                map.put(KEY_ID_TEAM_PLAYER, cursor.getString(6));
                playerList.add(map);
            }while (cursor.moveToNext());

        }
        Log.e("select sqlite " ,"" +playerList);
        database.close();
        return playerList;
    }

    public void insertPlayer(String fullname, String nickname, String posisi, String birth, String nopunggung, int idTeam){
        SQLiteDatabase database = this.getWritableDatabase();
        String insertValues = " INSERT INTO " + TABLE_PLAYER + "(fullname, nickname, posisi, birth, nopunggung, idteam)" +
                " VALUES ('"+fullname+"', '"+nickname+"', '"+posisi+"', '"+birth+"', '"+nopunggung+"', '"+idTeam+"') ";
        Log.e("insert sqlite" ,"" + insertValues);
        database.execSQL(insertValues);
        database.close();
    }

    public void updatePlayer(int id, String fullname, String nickname, String posisi, String birth, String nopunggung, int idteam){
        SQLiteDatabase database = this.getWritableDatabase();

        String updateQuery = " UPDATE " + TABLE_PLAYER + " SET "
                + FULL_NAME_PLAYER + "='" + fullname + "'"
                + NICK_NAME_PLAYER + "='" + nickname + "'"
                + POSISI_PLAYER + "='" + posisi + "'"
                + BIRTH_PLAYER + "='" + birth + "'"
                + NO_PUNGGUNG_PLAYER + "='" + nopunggung + "'"
                + KEY_ID_TEAM_PLAYER + "='" + idteam + "'"
                + " WHERE " + ID_PLAYER + "=" + "'" + id + "'";

        Log.e("update sqlite" , updateQuery);

        database.execSQL(updateQuery);
        database.close();
    }

    public void deletePlayer(int id){
        SQLiteDatabase database = this.getWritableDatabase();

        String deleteQuery = " DELETE FROM " + TABLE_PLAYER + " WHERE " + ID_PLAYER +
                "=" + "'" + id + "'";
        Log.e("delete" ,deleteQuery);
        database.execSQL(deleteQuery);
        database.close();
    }
    // -- AKHIR CRUD TABEL PLAYER -- \\

}
