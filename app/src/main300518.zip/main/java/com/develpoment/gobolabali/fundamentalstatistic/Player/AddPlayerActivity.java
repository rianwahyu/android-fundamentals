package com.develpoment.gobolabali.fundamentalstatistic.Player;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.EditText;

import com.develpoment.gobolabali.fundamentalstatistic.R;
import com.develpoment.gobolabali.fundamentalstatistic.Team.TeamActivity;

public class AddPlayerActivity extends AppCompatActivity {

    EditText etfullname, etnickname, etbirth, etpunggung, etteam;

    String idteamx,teamx;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_player);

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbarPlayer);
        toolbar.setTitle("Add Player");
        toolbar.setNavigationIcon(R.drawable.ic_back_white);
        toolbar.setTitleTextColor(Color.WHITE);
        setSupportActionBar(toolbar);

        idteamx = getIntent().getStringExtra("idx");
        teamx = getIntent().getStringExtra("namax");

        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(getApplicationContext(), PlayerActivity.class);
                i.putExtra("id",idteamx);
                i.putExtra("nama", teamx);
                startActivity(i);
                finish();
            }
        });



        etfullname = (EditText) findViewById(R.id.et_fullname);
        etnickname = (EditText) findViewById(R.id.et_nickname);
        etbirth = (EditText) findViewById(R.id.et_birth);
        etpunggung = (EditText) findViewById(R.id.et_noPunggung);
        etteam = (EditText) findViewById(R.id.et_team);

        etteam.setText(teamx);
        etteam.setEnabled(false);
    }

    @Override
    public void onBackPressed() {
        Intent i = new Intent(getApplicationContext(), PlayerActivity.class);
        i.putExtra("id",idteamx);
        i.putExtra("nama", teamx);
        startActivity(i);
        finish();
        super.onBackPressed();
    }
}
