package com.develpoment.gobolabali.fundamentalstatistic.Model;

/**
 * Created by Rian on 17/07/2018.
 */

public class Temp {
    public static String mode;

    public static String getMode() {
        return mode;
    }

    public static void setMode(String mode) {
        Temp.mode = mode;
    }
}
