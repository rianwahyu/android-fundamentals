package com.develpoment.gobolabali.fundamentalstatistic.Helpers;

import android.view.View;

public interface ItemClickListener {
    void onClick(View view, int i, boolean z);
}

