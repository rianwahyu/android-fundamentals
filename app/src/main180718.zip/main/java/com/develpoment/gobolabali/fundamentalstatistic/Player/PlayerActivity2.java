//package com.develpoment.gobolabali.fundamentalstatistic.Player;
//
//import android.annotation.SuppressLint;
//import android.content.Intent;
//import android.content.pm.ActivityInfo;
//import android.database.Cursor;
//import android.graphics.Color;
//import android.os.Bundle;
//import android.support.annotation.Nullable;
//import android.support.v7.app.AppCompatActivity;
//import android.support.v7.widget.DividerItemDecoration;
//import android.support.v7.widget.LinearLayoutManager;
//import android.support.v7.widget.RecyclerView;
//import android.support.v7.widget.Toolbar;
//import android.view.View;
//
//import com.develpoment.gobolabali.fundamentalstatistic.Adapter.PlayerAdapter;
//import com.develpoment.gobolabali.fundamentalstatistic.Adapter.PlayerMatchAdapter;
//import com.develpoment.gobolabali.fundamentalstatistic.Database.DatabaseHelper;
//import com.develpoment.gobolabali.fundamentalstatistic.Games.GameActivity;
//import com.develpoment.gobolabali.fundamentalstatistic.Model.DataPlayer;
//import com.develpoment.gobolabali.fundamentalstatistic.Model.DataPlayerMatch;
//import com.develpoment.gobolabali.fundamentalstatistic.R;
//import com.google.gson.Gson;
//
//import java.util.ArrayList;
//import java.util.List;
//
//public class PlayerActivity2 extends AppCompatActivity implements PlayerAdapter.ClickListener, PlayerMatchAdapter.ClickListener {
//
//    String action;
//    String cur_player;
//    String mode;
//    String player_old;
//    RecyclerView rv;
//    String v_match_id;
//    String v_player_id;
//    String v_position;
//    String v_team_name;
//
//    String idtournament,namatournament, idmatch,namamatch, idteam1, idteam2, category, namateam1,namateam2;
//
//    PlayerAdapter playerAdapter;
//    PlayerMatchAdapter playerMatchAdapter;
//    private DatabaseHelper db = new DatabaseHelper(this);
//
//
//    @SuppressLint("WrongConstant")
//    @Override
//    protected void onCreate(@Nullable Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        setContentView(R.layout.activity_player2);
//
//        idmatch     = getIntent().getStringExtra("idmatch");
//        namamatch   = getIntent().getStringExtra("nmmatch");
//        idteam1     = getIntent().getStringExtra("idteam1");
//        idteam2     = getIntent().getStringExtra("idteam2");
//        category    = getIntent().getStringExtra("category");
//        namateam1   = getIntent().getStringExtra("nmteam1");
//        namateam2   = getIntent().getStringExtra("nmteam2");
//
//        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbarPlayer);
//        toolbar.setTitle("PICK PLAYER");
////        toolbar.setSubtitle("Kategori : " + category);
//        toolbar.setNavigationIcon(R.drawable.ic_back_white);
//        toolbar.setTitleTextColor(Color.WHITE);
//        toolbar.setSubtitleTextColor(Color.WHITE);
//        setSupportActionBar(toolbar);
//
//        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                Intent intent = new Intent(getApplicationContext(), GameActivity.class);
////                intent.putExtra("idtournament", idturnament);
////                intent.putExtra("namatournament", namaturnament);
//                intent.putExtra("idmatch", idmatch);
//                intent.putExtra("nmmatch",namamatch);
//                intent.putExtra("idteam1",idteam1);
//                intent.putExtra("idteam2",idteam2);
//                intent.putExtra("nmteam1",namateam1);
//                intent.putExtra("nmteam2",namateam2);
//                intent.putExtra("category",category);
//
//                startActivity(intent);
//            }
//        });
//
//        v_team_name = getIntent().getStringExtra("v_team_name");
//        v_player_id = getIntent().getStringExtra("v_team_id");
//        v_match_id = getIntent().getStringExtra("v_match_id");
//        v_position = getIntent().getStringExtra("v_position");
//        action = getIntent().getStringExtra("action");
//        cur_player = getIntent().getStringExtra("cur_player");
//        mode = getIntent().getStringExtra("mode");
//        player_old = getIntent().getStringExtra("player_old");
//        try {
//            if ( action.equals("pick_player")) {
//                setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
//            }
//        } catch (Exception e) {
//        }
//
//        rv = (RecyclerView) findViewById(R.id.rv);
//        db = new DatabaseHelper(this);
//        playerAdapter = new PlayerAdapter(this);
//        String teamPos = "";
//        if ( v_match_id != null) {
//            if ( db.checkSide( v_match_id,  v_player_id).intValue() == 1) {
//                teamPos = "left";
//            } else {
//                teamPos = "right";
//            }
//            playerMatchAdapter = new PlayerMatchAdapter(this, teamPos);
//        }
//        getData();
//        setMainRecyclerView();
//
//    }
//
//    public void getData() {
//        Cursor c;
//        List<DataPlayerMatch> data = new ArrayList();
//        if (this.action.equals("pick_player")) {
//            c = db.getPlayerDataWhere(v_player_id, cur_player);
//            playerMatchAdapter.clear();
//        } else {
//            playerAdapter.clear();
//            c = db.getTeamPlayer(v_player_id);
//        }
//        if (c != null) {
//            while (c.moveToNext()) {
////                String nameText = c.getString(c.getColumnIndex(DBConfig.TOURNAMEN_COL_NAME));
////                String idText = c.getString(c.getColumnIndex(DBConfig.TOURNAMEN_COL_ID));
//                String playerNumberText = c.getString(c.getColumnIndex("player_number"));
//                String nicknameText = c.getString(c.getColumnIndex("nickname"));
//                DataPlayerMatch player = new DataPlayerMatch();
////                player.setName(nameText);
////                player.setId(idText);
////                player.setPlayer_number(playerNumberText);
//                player.setNickname(nicknameText);
//                if (action.equals("pick_player")) {
//                    String statusText = c.getString(c.getColumnIndex("status"));
//                    String positionText = c.getString(c.getColumnIndex("posnomor"));
//                    player.setStatus(statusText);
//                    player.setPosisi(positionText);
//                }
//                if (action.equals("pick_player")) {
//                    playerMatchAdapter.addItem(player);
//                } else {
//                    playerAdapter.addItem(player);
//                }
//            }
//        }
//    }
//
//    public void setMainRecyclerView() {
//        rv.setHasFixedSize(true);
//        rv.setLayoutManager(new LinearLayoutManager(this));
//        rv.addItemDecoration(new DividerItemDecoration(this, DividerItemDecoration.VERTICAL));
//        if ( action.equals("pick_player")) {
//            rv.setAdapter( playerMatchAdapter);
//        } else {
//            rv.setAdapter( playerAdapter);
//        }
//    }
//
//
//    @Override
//    public void onClick(int position) {
//        if (action.equals("pick_player")) {
//            DataPlayerMatch selectedItem = playerMatchAdapter.getSelectedItem(position);
//            Intent resultIntent = new Intent();
//            resultIntent.putExtra("ac_player_id", selectedItem.getIdPlayer());
//            resultIntent.putExtra("ac_player_number", selectedItem.getNopunggun());
//            resultIntent.putExtra("ac_player_nickname", selectedItem.getNickname());
//            resultIntent.putExtra("ac_player_mode", mode);
//            resultIntent.putExtra("ac_player_old", player_old);
//            resultIntent.putExtra("ac_player_team", v_player_id);
//            setResult(RESULT_OK, resultIntent);
//            finish();
//            return;
//        } else if (action.equals("pick_match_player")){
//            Object selectedItem2 = playerAdapter.getSelectedItem(position);
//            Intent returtnIntent = new Intent();
//            returtnIntent.putExtra("result", new Gson().toJson(selectedItem2));
//            setResult(RESULT_OK, returtnIntent);
//            finish();
//        }else {
//
//        }
////        selectedItem = this.playerAdapter.getSelectedItem(position);
////        Intent playerIntent = new Intent(getApplicationContext(), PlayerEditActivity.class);
////        playerIntent.putExtra("player_id", selectedItem.getId());
////        playerIntent.putExtra("player_name", selectedItem.getName());
////        playerIntent.putExtra("player_nickname", selectedItem.getNickname());
////        playerIntent.putExtra("player_number", selectedItem.getPlayer_number());
////        startActivity(playerIntent);
//    }
//
////    @Override
////    public void onBackPressed() {
////        Intent intent = new Intent(getApplicationContext(), GameActivity.class);
////        intent.putExtra("idmatch", idmatch);
////        intent.putExtra("nmmatch",namamatch);
////        intent.putExtra("idteam1",idteam1);
////        intent.putExtra("idteam2",idteam2);
////        intent.putExtra("nmteam1",namateam1);
////        intent.putExtra("nmteam2",namateam2);
////        intent.putExtra("category",category);
////        startActivity(intent);
////        super.onBackPressed();
////    }
//}
