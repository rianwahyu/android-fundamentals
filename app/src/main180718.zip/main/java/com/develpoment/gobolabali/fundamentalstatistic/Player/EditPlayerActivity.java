package com.develpoment.gobolabali.fundamentalstatistic.Player;

import android.annotation.SuppressLint;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.app.DialogFragment;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Toast;

import com.develpoment.gobolabali.fundamentalstatistic.Database.DatabaseHelper;
import com.develpoment.gobolabali.fundamentalstatistic.R;
import com.shashank.sony.fancydialoglib.Animation;
import com.shashank.sony.fancydialoglib.FancyAlertDialogListener;
import com.shashank.sony.fancydialoglib.Icon;
import com.weiwangcn.betterspinner.library.material.MaterialBetterSpinner;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.List;

public class EditPlayerActivity extends AppCompatActivity {

    EditText etfullname, etnickname, etbirth, etpunggung, etteam,etPosisi;

    Button submit,reset;
    MaterialBetterSpinner spinner1;

//    String idteamx,teamx;
    DatabaseHelper db = new DatabaseHelper(this);
    String posisiTampung;

    String idpx,fullpx,nickpx,pospx,birthpx,punggungpx,idteampx, namateampx;

    String teamnamex;

    Context context = EditPlayerActivity.this;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_player);

        idpx = getIntent().getStringExtra("id");
        fullpx = getIntent().getStringExtra("fullname");
        nickpx = getIntent().getStringExtra("nickname");
   //     pospx = getIntent().getStringExtra("posisi");
//        birthpx = getIntent().getStringExtra("birth");
        punggungpx = getIntent().getStringExtra("punggung");
        idteampx = getIntent().getStringExtra("rian_id_team");


        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbarPlayer);
        if (idpx == null){
            toolbar.setTitle("New Player");
        }else {
            toolbar.setTitle("Edit Player");
        }
//        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
//        getSupportActionBar().setHomeButtonEnabled(true);
        toolbar.setNavigationIcon(R.drawable.ic_back_white);
        toolbar.setTitleTextColor(Color.WHITE);
        setSupportActionBar(toolbar);



        etfullname = (EditText) findViewById(R.id.et_fullname);
        etnickname = (EditText) findViewById(R.id.et_nickname);
//        etbirth = (EditText) findViewById(R.id.et_birth);
        etpunggung = (EditText) findViewById(R.id.et_noPunggung);
        etteam = (EditText) findViewById(R.id.et_team);
//        spinner1 = (MaterialBetterSpinner) findViewById(R.id.spinner1);

        submit = (Button) findViewById(R.id.buttonSubmitPlayer);
        reset = (Button) findViewById(R.id.buttonResetPlayer);

        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
//                cekPlayer();

                if (idpx !=null){
                    updateData();
                }else {
                    saveData();
                }
            }
        });

        reset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                new com.shashank.sony.fancydialoglib.FancyAlertDialog.Builder(EditPlayerActivity.this)
                        .setTitle("Reset Form !")
                        .setBackgroundColor(Color.parseColor("#E12929"))
                        .setIcon(R.drawable.reset_icon_white, Icon.Visible)
                        .setMessage("Apakah Anda Yakin Reset Form ?")
                        .setNegativeBtnText("Tidak")
                        .setNegativeBtnBackground(Color.parseColor("#ffc371"))
                        .setPositiveBtnText("Ya")
                        .setPositiveBtnBackground(Color.parseColor("#0d488a"))
                        .setAnimation(Animation.SIDE)
                        .isCancellable(true)
                        .OnPositiveClicked(new FancyAlertDialogListener() {
                            @Override
                            public void OnClick() {
                                etfullname.setText("");
                                etnickname.setText("");
                                etbirth.setText("");
                                etpunggung.setText("");
//                                etteam.setText("");
                                spinner1.setText("");
                            }
                        })
                        .OnNegativeClicked(new FancyAlertDialogListener() {
                            @Override
                            public void OnClick() {

                            }
                        })
                        .build();
            }
        });

        etfullname.setText(fullpx);
        etnickname.setText(nickpx);
//        spinner1.setText(pospx);
//        etbirth.setText(birthpx);
        etpunggung.setText(punggungpx);

        etteam.setText(db.getTeamName(idteampx));
        etteam.setEnabled(false);
        teamnamex = db.getTeamName(idteampx);

        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
                return;
            }
        });


        setupData();

    }

    private void setupData() {
        etfullname.setText(fullpx);
        etnickname.setText(nickpx);
        etpunggung.setText(punggungpx);
    }


    private void cekPlayer() {
        String fullname = etfullname.getText().toString().trim().toUpperCase();
        String nickname = etnickname.getText().toString().trim().toUpperCase();


//        String birth = etbirth.getText().toString().trim().toUpperCase();
        String nopunggung = etpunggung.getText().toString().trim().toUpperCase();
        String status ="0";

        if (fullname.equals("")||nickname.equals("")||nopunggung.equals("")||idteampx.equals("")){
            Toast.makeText(getApplicationContext(),"Harap isi Semua Data", Toast.LENGTH_LONG).show();
        }else {
            db.updatePlayer(Integer.parseInt(idpx),fullname,nickname,nopunggung,Integer.parseInt(idteampx));
            Toast.makeText(getApplicationContext(),"Sukses Edit Player !", Toast.LENGTH_LONG).show();
            Intent i = new Intent(getApplicationContext(), PlayerActivity.class);
            i.putExtra("id",idteampx);
            i.putExtra("nama", teamnamex);
            startActivity(i);
            finish();
        }

    }

    /*
    @Override
    public void onBackPressed() {
        Intent i = new Intent(getApplicationContext(), PlayerActivity.class);
        i.putExtra("id",idteampx);
        i.putExtra("nama", teamnamex);
        startActivity(i);
        finish();
        super.onBackPressed();
    }*/


    private void saveData() {
        boolean valid = true;
        if (etfullname.getText().length() < 1) {
            etfullname.setError("Required!");
            valid = false;
        }
        if (etnickname.getText().length() < 1) {
            etnickname.setError("Required!");
            valid = false;
        }
        if (etpunggung.getText().length() < 1) {
            etpunggung.setError("Required!");
            valid = false;
        }
        if (valid) {
            String data_name = etfullname.getText().toString();
            String data_nickname = etnickname.getText().toString();
            String data_number = etpunggung.getText().toString();
            ContentValues cv = new ContentValues();
            cv.put("fullname", data_name);
            cv.put("nickname", data_nickname);
            cv.put("nopunggung", data_number);
            cv.put("idteam", idteampx);
            DatabaseHelper dbConfig = new DatabaseHelper(this);
            long pid = dbConfig.saveDataWithId("player", cv);
            ContentValues cv1 = new ContentValues();
            cv1.put("idplayer", Long.valueOf(pid));
            cv1.put("idteam", idteampx);
            dbConfig.saveData("team_player", cv1);
            Toast.makeText(getApplicationContext(),"Berhasil", Toast.LENGTH_SHORT).show();
            onBackPressed();
            return;
        }
    }

    private void updateData() {
        CharSequence data_name = etfullname.getText().toString();
        if (Boolean.valueOf(new DatabaseHelper(this).updatePlayer(idpx, (String) data_name, etnickname.getText().toString(), etpunggung.getText().toString())).booleanValue()) {
            Toast.makeText(getApplicationContext(),"Berhasil", Toast.LENGTH_SHORT).show();
            getSupportActionBar().setSubtitle(data_name);
            onBackPressed();
            return;
        }
        Toast.makeText(getApplicationContext(),"GAGAL", Toast.LENGTH_SHORT).show();
    }

    /*public void runSnack(String msg) {
        Snackbar.make(this.coordinatorLayout, (CharSequence) msg, 0).show();
    }*/
}
