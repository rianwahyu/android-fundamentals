package com.develpoment.gobolabali.fundamentalstatistic.Model;

public class Temp {
    public static String status;

    public static String getStatus() {
        return status;
    }

    public static void setStatus(String status) {
        Temp.status = status;
    }
}
