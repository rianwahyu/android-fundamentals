package com.develpoment.gobolabali.fundamentalstatistic.Fragment;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import com.develpoment.gobolabali.fundamentalstatistic.Adapter.PlayerMatchAdapterLineUp;
import com.develpoment.gobolabali.fundamentalstatistic.Database.DatabaseHelper;
import com.develpoment.gobolabali.fundamentalstatistic.Model.Player;
import com.develpoment.gobolabali.fundamentalstatistic.Player.PlayerMatchEditActivity;
import com.develpoment.gobolabali.fundamentalstatistic.R;
import com.google.gson.Gson;

import java.util.ArrayList;
import java.util.List;

public class FragmentPlayer2 extends Fragment implements PlayerMatchAdapterLineUp.ClickListener {

    String idteam, idtournament, idmatch, poss;
    private Bundle bundle1;
    RecyclerView rv;

    private LinearLayoutManager layoutManager;
    private PlayerMatchAdapterLineUp playerMatchAdapter;
    private DatabaseHelper db = new DatabaseHelper(getActivity());


    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        bundle1 = this.getArguments();
        idteam = bundle1.getString("idteam");
        idtournament = bundle1.getString("idtournament");
        idmatch = bundle1.getString("idmatch");
        poss = bundle1.getString("pos");
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View frag = inflater.inflate(R.layout.fragment_player2,container,false);

        rv = (RecyclerView) frag.findViewById(R.id.listfragteam2);
        db = new DatabaseHelper(getActivity());
        playerMatchAdapter = new PlayerMatchAdapterLineUp(this, poss);
        getData();
        setMainRecyclerView();
        return frag;
    }


    public void getData() {
        List<Player> data = new ArrayList();
        Cursor c = db.getPlayerByMatchTeam(idteam, idmatch);
        if (c != null) {
            while (c.moveToNext()) {
                String nameText = c.getString(c.getColumnIndex("fullname"));
                String idText = c.getString(c.getColumnIndex("id"));
                String playerNumberText = c.getString(c.getColumnIndex("nopunggung"));
                String nicknameText = c.getString(c.getColumnIndex("nickname"));
                String statusText = c.getString(c.getColumnIndex("status"));
                String positionText = c.getString(c.getColumnIndex("posnomor"));

                Player player = new Player();
                player.setName(nameText);
                player.setId(idText);
                player.setPlayer_number(playerNumberText);
                player.setNickname(nicknameText);
                player.setStatus(statusText);
                player.setPosition(positionText);
                playerMatchAdapter.addItem(player);
                Log.e("TAG", "POS:" + positionText);

            }
        }
    }

    public void setMainRecyclerView() {
        rv.setHasFixedSize(true);
        rv.setLayoutManager(new LinearLayoutManager(getActivity()));
        rv.addItemDecoration(new DividerItemDecoration(getActivity(), DividerItemDecoration.VERTICAL));
        rv.setAdapter(playerMatchAdapter);
    }


    @Override
    public void onClick(int position) {
        Player selectedItem = playerMatchAdapter.getSelectedItem(position);
        Log.e("log", new Gson().toJson(selectedItem));
        String matchPlayer = new Gson().toJson(selectedItem);
        Intent playerIntent = new Intent(getActivity(), PlayerMatchEditActivity.class);
        playerIntent.putExtra("idplayer", selectedItem.getId());
        playerIntent.putExtra("fullname", selectedItem.getName());
        playerIntent.putExtra("nickname", selectedItem.getNickname());
        playerIntent.putExtra("nopunggung", selectedItem.getPlayer_number());
        playerIntent.putExtra("pos", poss);
        playerIntent.putExtra("DATA", matchPlayer);
        playerIntent.putExtra("match_id", idmatch);
        playerIntent.putExtra("idteam", idteam);
        playerIntent.putExtra("extra_player", new Gson().toJson(new Player()));
        startActivity(playerIntent);
    }
}
