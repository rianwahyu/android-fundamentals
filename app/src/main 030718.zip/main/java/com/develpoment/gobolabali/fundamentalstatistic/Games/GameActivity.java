package com.develpoment.gobolabali.fundamentalstatistic.Games;

import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Vibrator;
import android.support.annotation.Nullable;
import android.support.design.widget.CoordinatorLayout;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.util.TypedValue;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.develpoment.gobolabali.fundamentalstatistic.Adapter.AdapterPlayerPosition;
import com.develpoment.gobolabali.fundamentalstatistic.Adapter.AdapterPlayerPosition2;
import com.develpoment.gobolabali.fundamentalstatistic.Adapter.CadanganAdapter;
import com.develpoment.gobolabali.fundamentalstatistic.Adapter.CadanganAdapter2;
import com.develpoment.gobolabali.fundamentalstatistic.Database.DatabaseHelper;
import com.develpoment.gobolabali.fundamentalstatistic.Model.DataPlayer;
import com.develpoment.gobolabali.fundamentalstatistic.Model.DataPlayer2;
import com.develpoment.gobolabali.fundamentalstatistic.Model.DataPlayerMatch;
import com.develpoment.gobolabali.fundamentalstatistic.Player.PlayerActivity;
import com.develpoment.gobolabali.fundamentalstatistic.R;

import java.util.ArrayList;
import java.util.List;

public class GameActivity extends AppCompatActivity implements CadanganAdapter.ClickListener, CadanganAdapter2.ClickListener {

    String action;
    String action_name;
    boolean boolCadangan = true;
    int boolMode = 0;
    public Button btnLeft11;
    public Button btnLeft21;
    public Button btnLeft22;
    public Button btnLeft23;
    public Button btnLeft24;
    public Button btnLeft31;
    public Button btnLeft32;
    public Button btnLeft33;
    public Button btnLeft34;
    public Button btnLeft41;
    public Button btnLeft42;
    public Button btnLeft43;
    public Button btnLeft44;
    public Button btnRight11;
    public Button btnRight21;
    public Button btnRight22;
    public Button btnRight23;
    public Button btnRight24;
    public Button btnRight31;
    public Button btnRight32;
    public Button btnRight33;
    public Button btnRight34;
    public Button btnRight41;
    public Button btnRight42;
    public Button btnRight43;
    public Button btnRight44;

    public TextView txtLeft11;
    public TextView txtLeft21;
    public TextView txtLeft22;
    public TextView txtLeft23;
    public TextView txtLeft24;
    public TextView txtLeft31;
    public TextView txtLeft32;
    public TextView txtLeft33;
    public TextView txtLeft34;
    public TextView txtLeft41;
    public TextView txtLeft42;
    public TextView txtLeft43;
    public TextView txtLeft44;
    public TextView txtRight11;
    public TextView txtRight21;
    public TextView txtRight22;
    public TextView txtRight23;
    public TextView txtRight24;
    public TextView txtRight31;
    public TextView txtRight32;
    public TextView txtRight33;
    public TextView txtRight34;
    public TextView txtRight41;
    public TextView txtRight42;
    public TextView txtRight43;
    public TextView txtRight44;

    CadanganAdapter cadanganAdapter1;
    CadanganAdapter2 cadanganAdapter2;
    LinearLayout content_match;
    public CoordinatorLayout coordinatorLayout;
    String curCadanganNickname = "";
    String curCadanganNo = null;
    String curCadanganTeam = "";

    Boolean editMode = Boolean.valueOf(false);
    double hCadangan;

    List<String> kananList = new ArrayList();
    List<String> kiriList = new ArrayList();
    public Button[] listButton = new Button[]{btnLeft11, btnLeft21, btnLeft22, btnLeft23, btnLeft24, btnLeft31, btnLeft32, btnLeft33, btnLeft34, btnLeft41, btnLeft42, btnLeft43, btnLeft44, btnRight11, btnRight21, btnRight22, btnRight23, btnRight24, btnRight31, btnRight32, btnRight33, btnRight34, btnRight41, btnRight42, btnRight43, btnRight44};
    public String[] listPosition = new String[]{"11", "21", "22", "23", "24", "31", "32", "33", "34", "41", "42", "43", "44"};
    public TextView[] listTextView = new TextView[]{txtLeft11, txtLeft21, txtLeft22, txtLeft23, txtLeft24, txtLeft31, txtLeft32, txtLeft33, txtLeft34, txtLeft41, txtLeft42, txtLeft43, txtLeft44,txtRight11, txtRight21, txtRight22, txtRight23, txtRight24, txtRight31, txtRight32, txtRight33, txtRight34, txtRight41, txtRight42, txtRight43, txtRight44};
    LinearLayout llCadangan;
    public LinearLayout llField;
    ProgressDialog mDialog;
//    RestManager mManager;
    String match_id;
    String match_name;
    RecyclerView rv1;
    RecyclerView rv2;
    Button selButton;
    TextView selText;
    String team_a;
    String team_b;
    Toolbar toolbar;

    String idtournament,namatournament, idmatch,namamatch, idteam1, idteam2, category, namateam1,namateam2;
    private LinearLayoutManager layoutManager;
    private AdapterPlayerPosition adapterPlayer;
    private AdapterPlayerPosition2 adapterPlayer2;


    private DatabaseHelper db = new DatabaseHelper(this);


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game);

        idmatch     = getIntent().getStringExtra("idmatch");
        namamatch   = getIntent().getStringExtra("nmmatch");
        idteam1     = getIntent().getStringExtra("idteam1");
        idteam2     = getIntent().getStringExtra("idteam2");
        category    = getIntent().getStringExtra("category");
        namateam1   = getIntent().getStringExtra("nmteam1");
        namateam2   = getIntent().getStringExtra("nmteam2");

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbarGame);
        toolbar.setTitle(namamatch + "   ( " +namateam1 + " " + " vs " +" " + namateam2 +" )");
        toolbar.setSubtitle("Kategori : " + category);
        toolbar.setNavigationIcon(R.drawable.ic_back_white);
        toolbar.setTitleTextColor(Color.WHITE);
        toolbar.setSubtitleTextColor(Color.WHITE);
        setSupportActionBar(toolbar);

        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(getApplicationContext(), GameChooseActivity.class);
                startActivity(i);
                finish();
            }
        });

        llField = (LinearLayout) findViewById(R.id.soccer_field);
        llCadangan = (LinearLayout) findViewById(R.id.llCadangan);
        content_match = (LinearLayout) findViewById(R.id.content_match);
        coordinatorLayout = (CoordinatorLayout) findViewById(R.id.colayoutGame);
        txtLeft11 = (TextView) findViewById(R.id.ltext_1_1);
        txtLeft21 = (TextView) findViewById(R.id.ltext_2_1);
        txtLeft22 = (TextView) findViewById(R.id.ltext_2_2);
        txtLeft23 = (TextView) findViewById(R.id.ltext_2_3);
        txtLeft24 = (TextView) findViewById(R.id.ltext_2_4);
        txtLeft31 = (TextView) findViewById(R.id.ltext_3_1);
        txtLeft32 = (TextView) findViewById(R.id.ltext_3_2);
        txtLeft33 = (TextView) findViewById(R.id.ltext_3_3);
        txtLeft34 = (TextView) findViewById(R.id.ltext_3_4);
        txtLeft41 = (TextView) findViewById(R.id.ltext_4_1);
        txtLeft42 = (TextView) findViewById(R.id.ltext_4_2);
        txtLeft43 = (TextView) findViewById(R.id.ltext_4_3);
        txtLeft44 = (TextView) findViewById(R.id.ltext_4_4);

        txtRight11 = (TextView) findViewById(R.id.rtext_1_1);
        txtRight21 = (TextView) findViewById(R.id.rtext_2_1);
        txtRight22 = (TextView) findViewById(R.id.rtext_2_2);
        txtRight23 = (TextView) findViewById(R.id.rtext_2_3);
        txtRight24 = (TextView) findViewById(R.id.rtext_2_4);
        txtRight31 = (TextView) findViewById(R.id.rtext_3_1);
        txtRight32 = (TextView) findViewById(R.id.rtext_3_2);
        txtRight33 = (TextView) findViewById(R.id.rtext_3_3);
        txtRight34 = (TextView) findViewById(R.id.rtext_3_4);
        txtRight41 = (TextView) findViewById(R.id.rtext_4_1);
        txtRight42 = (TextView) findViewById(R.id.rtext_4_2);
        txtRight43 = (TextView) findViewById(R.id.rtext_4_3);
        txtRight44 = (TextView) findViewById(R.id.rtext_4_4);

        setupFieldMode(boolMode);
        setupButton();
    }


    private void setupFieldMode(int mode) {
        int width = getWindowManager().getDefaultDisplay().getWidth();

        if (mode == 0) {
            llField.setLayoutParams(new LinearLayout.LayoutParams(-1, (int) (((double) width) / 1.7d)));
        }else {
            llField.setLayoutParams(new LinearLayout.LayoutParams(-1, (int) ((double) (this.content_match.getHeight() - ((int) TypedValue.applyDimension(1, 62.0f, getResources().getDisplayMetrics()))))));
        }
    }

    private void setupButton() {
        btnLeft11 = (Button) findViewById(R.id.left_1_1);
        btnLeft21 = (Button) findViewById(R.id.left_2_1);
        btnLeft22 = (Button) findViewById(R.id.left_2_2);
        btnLeft23 = (Button) findViewById(R.id.left_2_3);
        btnLeft24 = (Button) findViewById(R.id.left_2_4);
        btnLeft31 = (Button) findViewById(R.id.left_3_1);
        btnLeft32 = (Button) findViewById(R.id.left_3_2);
        btnLeft33 = (Button) findViewById(R.id.left_3_3);
        btnLeft34 = (Button) findViewById(R.id.left_3_4);
        btnLeft41 = (Button) findViewById(R.id.left_4_1);
        btnLeft42 = (Button) findViewById(R.id.left_4_2);
        btnLeft43 = (Button) findViewById(R.id.left_4_3);
        btnLeft44 = (Button) findViewById(R.id.left_4_4);

        btnRight11 = (Button) findViewById(R.id.right_1_1);
        btnRight21 = (Button) findViewById(R.id.right_2_1);
        btnRight22 = (Button) findViewById(R.id.right_2_2);
        btnRight23 = (Button) findViewById(R.id.right_2_3);
        btnRight24 = (Button) findViewById(R.id.right_2_4);
        btnRight31 = (Button) findViewById(R.id.right_3_1);
        btnRight32 = (Button) findViewById(R.id.right_3_2);
        btnRight33 = (Button) findViewById(R.id.right_3_3);
        btnRight34 = (Button) findViewById(R.id.right_3_4);
        btnRight41 = (Button) findViewById(R.id.right_4_1);
        btnRight42 = (Button) findViewById(R.id.right_4_2);
        btnRight43 = (Button) findViewById(R.id.right_4_3);
        btnRight44 = (Button) findViewById(R.id.right_4_4);

        btnLeft11.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View view) {
                executeLong(idteam1, btnLeft11, txtLeft11 );
                return false;
            }
        });

        btnLeft11.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                executeClick((Button) view, idteam1);
            }
        });

        btnLeft21.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View view) {
                executeLong(idteam1, btnLeft21, txtLeft21 );
                return false;
            }
        });

        btnLeft21.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                executeClick((Button) view, idteam1);
            }
        });

        btnLeft22.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View view) {
                executeLong(idteam1, btnLeft22, txtLeft22 );
                return false;
            }
        });

        btnLeft22.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                executeClick((Button) view, idteam1);
            }
        });

        btnLeft23.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View view) {
                executeLong(idteam1, btnLeft23, txtLeft23 );
                return false;
            }
        });

        btnLeft23.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                executeClick((Button) view, idteam1);
            }
        });

        btnLeft24.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View view) {
                executeLong(idteam1, btnLeft24, txtLeft24 );
                return false;
            }
        });

        btnLeft24.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                executeClick((Button) view, idteam1);
            }
        });

        btnLeft31.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View view) {
                executeLong(idteam1, btnLeft31, txtLeft31 );
                return false;
            }
        });

        btnLeft31.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                executeClick((Button) view, idteam1);
            }
        });

        btnLeft32.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View view) {
                executeLong(idteam1, btnLeft32, txtLeft32 );
                return false;
            }
        });

        btnLeft32.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                executeClick((Button) view, idteam1);
            }
        });

        btnLeft33.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View view) {
                executeLong(idteam1, btnLeft33, txtLeft33 );
                return false;
            }
        });

        btnLeft33.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                executeClick((Button) view, idteam1);
            }
        });

        btnLeft34.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View view) {
                executeLong(idteam1, btnLeft34, txtLeft34 );
                return false;
            }
        });

        btnLeft34.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                executeClick((Button) view, idteam1);
            }
        });

        btnLeft41.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View view) {
                executeLong(idteam1, btnLeft41, txtLeft41 );
                return false;
            }
        });

        btnLeft41.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                executeClick((Button) view, idteam1);
            }
        });

        btnLeft42.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View view) {
                executeLong(idteam1, btnLeft42, txtLeft42 );
                return false;
            }
        });

        btnLeft42.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                executeClick((Button) view, idteam1);
            }
        });

        btnLeft43.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View view) {
                executeLong(idteam1, btnLeft43, txtLeft43 );
                return false;
            }
        });

        btnLeft43.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                executeClick((Button) view, idteam1);
            }
        });

        btnLeft44.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View view) {
                executeLong(idteam1, btnLeft44, txtLeft44 );
                return false;
            }
        });

        btnLeft44.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                executeClick((Button) view, idteam1);
            }
        });

        btnRight11.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View view) {
                executeLong(idteam2, btnRight11, txtRight11 );
                return false;
            }
        });

        btnRight11.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                executeClick((Button) view, idteam2);
            }
        });

        btnRight21.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View view) {
                executeLong(idteam2, btnRight21, txtRight21 );
                return false;
            }
        });

        btnRight21.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                executeClick((Button) view, idteam2);
            }
        });

        btnRight22.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View view) {
                executeLong(idteam2, btnRight22, txtRight22 );
                return false;
            }
        });

        btnRight22.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                executeClick((Button) view, idteam2);
            }
        });

        btnRight23.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View view) {
                executeLong(idteam2, btnRight23, txtRight23 );
                return false;
            }
        });

        btnRight23.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                executeClick((Button) view, idteam2);
            }
        });

        btnRight24.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View view) {
                executeLong(idteam2, btnRight24, txtRight24 );
                return false;
            }
        });

        btnRight24.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                executeClick((Button) view, idteam2);
            }
        });

        btnRight31.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View view) {
                executeLong(idteam2, btnRight31, txtRight31 );
                return false;
            }
        });

        btnRight31.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                executeClick((Button) view, idteam2);
            }
        });

        btnRight32.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View view) {
                executeLong(idteam2, btnRight33, txtRight32 );
                return false;
            }
        });

        btnRight32.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                executeClick((Button) view, idteam2);
            }
        });

        btnRight34.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View view) {
                executeLong(idteam2, btnRight34, txtRight34 );
                return false;
            }
        });

        btnRight34.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                executeClick((Button) view, idteam2);
            }
        });

        btnRight33.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View view) {
                executeLong(idteam2, btnRight33, txtRight33 );
                return false;
            }
        });

        btnRight33.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                executeClick((Button) view, idteam2);
            }
        });

        btnRight41.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View view) {
                executeLong(idteam2, btnRight41, txtRight41 );
                return false;
            }
        });

        btnRight41.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                executeClick((Button) view, idteam2);
            }
        });

        btnRight42.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View view) {
                executeLong(idteam2, btnRight42, txtRight42 );
                return false;
            }
        });

        btnRight42.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                executeClick((Button) view, idteam2);
            }
        });

        btnRight43.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View view) {
                executeLong(idteam2, btnRight43, txtRight43 );
                return false;
            }
        });

        btnRight43.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                executeClick((Button) view, idteam2);
            }
        });

        btnRight44.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View view) {
                executeLong(idteam2, btnRight44, txtRight44 );
                return false;
            }
        });

        btnRight44.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                executeClick((Button) view, idteam2);
            }
        });

        setupRvCadangan();

    }

    private void setupRvCadangan() {
        rv1 = (RecyclerView) findViewById(R.id.rvTeamA);
        rv2 = (RecyclerView) findViewById(R.id.rvTeamB);
        cadanganAdapter1 = new CadanganAdapter(this);
        cadanganAdapter2 = new CadanganAdapter2(this);
        getCadangan(idteam1, cadanganAdapter1, null);
        getCadangan(idteam2, null, cadanganAdapter2);
        rv1.setHasFixedSize(true);
        rv1.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false));
        rv1.setAdapter(cadanganAdapter1);
        rv2.setHasFixedSize(true);
        rv2.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false));
        rv2.setAdapter(cadanganAdapter2);

    }

    private void getCadangan(String team, CadanganAdapter pa, CadanganAdapter2 pa2) {
        List<DataPlayerMatch> dataPlayers = new ArrayList<>();
        Cursor c = db.getPlayerCadangan2(team, idmatch);

        if (c !=null){
            if (pa == null){
                pa2.clearItem();
            }else {
                pa.clearItem();
            }

            while (c.moveToNext()){

                String idplayer = c.getString(c.getColumnIndex("idplayer"));
                String status = c.getString(c.getColumnIndex("status"));
                String nopunggung = c.getString(c.getColumnIndex("nopunggung"));
                String nickname = c.getString(c.getColumnIndex("nickname"));

                DataPlayerMatch dataPlayer2 = new DataPlayerMatch();
                dataPlayer2.setIdPlayer(idplayer);
                dataPlayer2.setNopunggun(nopunggung);
                dataPlayer2.setStatus(status);
                dataPlayer2.setNickname(nickname);

                if (pa == null){
                    pa2.addItem(dataPlayer2);
                }else {
                    pa.addItem(dataPlayer2);
                }
            }
        }
    }

    private void executeLong(String idteam, Button btn, TextView txt) {
        String btext = btn.getText().toString();
        Log.e("LOG-TEXT", btext);
        if (btext.equals("")){
            openPlayer("new", idteam, btn, txt);
        }else {
            openPlayerOpt(idteam, btn, txt);
        }
    }



    private void executeClick(Button b, String idteam) {
        String btext = b.getText().toString();
        if (!btext.equals("")){
            if (!editMode.booleanValue()){
                runAction(idteam, btext);
            } else if (curCadanganTeam.equals(idteam)){
                openCadangan(idteam, b, getTextView(getIndexButton(b)));
                runSnack("Berhasil dipilih");
                fieldMode(Boolean.valueOf(true));
                loadCadangan();
            }else {
                runSnack("Pemain ini tidak bisa dipilih. Pilih pemain dari tim asal.");
            }
        }
    }

    private void loadCadangan() {
        getCadangan(idteam1, cadanganAdapter1,null);
        getCadangan(idteam2, null, cadanganAdapter2);
    }

    private void fieldMode(Boolean b) {
        if (b.booleanValue()){
            editMode = Boolean.valueOf(false);
            llField.setBackgroundResource(R.drawable.field);
            curCadanganNickname = "";
            curCadanganTeam ="";
            curCadanganNo ="";
            return;
        }
        editMode = Boolean.valueOf(true);
        llField.setBackgroundResource(R.color.colorGreyDark);

    }


    public void openPlayer(String mode, String idteam, Button btn, TextView txt) {
        String curpos;
        String arrJoined;
        this.selButton = btn;
        this.selText = txt;
        String pos = checkTeam(idteam);
        int idxButton = getIndexButton(btn);
        int listLen = this.listPosition.length;
        if (idxButton >= listLen) {
            curpos = this.listPosition[idxButton - listLen];
        } else {
            curpos = this.listPosition[idxButton];
        }
        Intent playerIntent = new Intent(this, PlayerActivity.class);
        playerIntent.putExtra("v_team_id", idteam);
        playerIntent.putExtra("v_match_id", match_id);
        playerIntent.putExtra("v_position", curpos);
        playerIntent.putExtra("action", "pick_player");
        if (pos.equals("left")) {
            arrJoined = joinList(this.kiriList, ",");
        } else {
            arrJoined = joinList(this.kananList, ",");
        }
        playerIntent.putExtra("mode", mode);
        playerIntent.putExtra("cur_player", arrJoined);
        playerIntent.putExtra("player_old", btn.getText().toString());
        startActivityForResult(playerIntent, 222);
    }


    private void openCadangan(String idteam, Button b, TextView textView) {
        List<String> list;
        String playerOld = b.getText().toString();
        selButton = b;
        selText = textView;

        if (checkTeam(idteam).equals("left")){
            list = kiriList;
            selButton.setBackgroundResource(R.drawable.touch_green);
        }else {
            list = kananList;
            selButton.setBackgroundResource(R.drawable.touch_blue);
        }
        removeItem(list, playerOld);
        String cadanganId = db.getPlayerId(idteam, idmatch, curCadanganNo);
        db.updateFormation(idmatch, idteam, playerOld, cadanganId, getPositionName(selButton));
        selButton.setText(curCadanganNo);
        selText.setText(curCadanganNickname);
        
    }

    private void removeItem(List<String> list, String val) {
        for (int i=0; i<list.size(); i++){
            if (((String) list.get(i)).equals(val)){
                list.remove(i);
                return;
            }
        }
    }

    public String checkTeam(String idteam) {
        if (idteam.equals(idteam1)){
            return "left";
        }

        return "right";
    }

    @SuppressLint("WrongConstant")
    private void runAction(String idteam, String playernumber) {
        Log.e("PID",db.getPlayerId(idteam, idmatch, playernumber));
        if (category.equals("PLAYER")){

        }else if (category.equals("GOALKEEPER")){

        }else {
            runSnack("+1 " + this.action_name + " untuk pemain nomor " + playernumber);
            ((Vibrator) getApplicationContext().getSystemService("vibrator")).vibrate(500);
            //executeDetail(category, idteam, playernumber);
        }
//        Log.d("PID", )
    }

    private void executeDetail(String category, String idteam, String playernumber) {

    }

    public int getIndex(String[] list, String data) {
        for (int i = 0; i < list.length; i++) {
            if (list[i].equals(data)) {
                return i;
            }
        }
        return -1;
    }

    public int getIndexButton(Button button) {
        Button[] listButton = new Button[]{this.btnLeft11, this.btnLeft21, this.btnLeft22, this.btnLeft23, this.btnLeft24, this.btnLeft31, this.btnLeft32, this.btnLeft33, this.btnLeft34, this.btnLeft41, this.btnLeft42, this.btnLeft43, this.btnLeft44, this.btnRight11, this.btnRight21, this.btnRight22, this.btnRight23, this.btnRight24, this.btnRight31, this.btnRight32, this.btnRight33, this.btnRight34, this.btnRight41, this.btnRight42, this.btnRight43, this.btnRight44};
        for (int i = 0; i < listButton.length; i++) {
            if (listButton[i] == button) {
                return i;
            }
        }
        return -1;
    }
    public TextView getTextView(int index) {
        return new TextView[]{txtLeft11, txtLeft21, txtLeft22, txtLeft23, txtLeft24, txtLeft31, txtLeft32, txtLeft33, txtLeft34, txtLeft41, txtLeft42, txtLeft43, txtLeft44, txtRight11, txtRight21, txtRight22, txtRight23, txtRight24, txtRight31, txtRight32, txtRight33, txtRight34, txtRight41, txtRight42, txtRight43, txtRight44}[index];
    }


    /*
    private void loadGk1() {
//        rcgkteam1.setVisibility(View.VISIBLE);
//        rcgkteam1.setHasFixedSize(true);
//        layoutManager = new LinearLayoutManager(this);
//        rcgkteam1.setLayoutManager(layoutManager);
//        recyclerView = (RecyclerView) findViewById(R.id.rcPlayer);
        rccoba.setHasFixedSize(true);
        layoutManager = new LinearLayoutManager(this);
        rccoba.setLayoutManager(layoutManager);
        String posisih = "GOALKEEPER";


        db = new DatabaseHelper(GameActivity.this);
//        teamList = db.getTeam();
//        adapterTeam = new AdapterTeam(teamList);
//        recyclerView.setAdapter(adapterTeam);

        ArrayList<HashMap<String,String>> row = db.getAllPlayerPosition(Integer.parseInt(idteam1), posisih);

        for (int i=0; i <row.size(); i++){
            String id = row.get(i).get("id");
            String fullname = row.get(i).get("fullname");
            String nickname = row.get(i).get("nickname");
            String posisi = row.get(i).get("posisi");
            String nopunggung = row.get(i).get("nopunggung");
            String idteam = row.get(i).get("idteam");

            DataPlayer dataPlayer = new DataPlayer();
            dataPlayer.setId(id);
            dataPlayer.setFullname(fullname);
            dataPlayer.setNickname(nickname);
            dataPlayer.setPosisi(posisi);

            dataPlayer.setNopunggung(nopunggung);
            dataPlayer.setIdteam(idteam);

            playerList.add(dataPlayer);
        }

//        adapterPlayer = new AdapterPlayerPosition(playerList);
        adapterPlayer = new AdapterPlayerPosition(GameActivity.this,playerList);
        rccoba.setAdapter(adapterPlayer);
        adapterPlayer.notifyDataSetChanged();

    }

    private void loadGk2() {
//        rcgkteam1.setVisibility(View.VISIBLE);
//        rcgkteam1.setHasFixedSize(true);
//        layoutManager = new LinearLayoutManager(this);
//        rcgkteam1.setLayoutManager(layoutManager);
//        recyclerView = (RecyclerView) findViewById(R.id.rcPlayer);
        rccoba2.setHasFixedSize(true);
        layoutManager = new LinearLayoutManager(this);
        rccoba2.setLayoutManager(layoutManager);
        String posisih = "GOALKEEPER";


        db = new DatabaseHelper(GameActivity.this);
//        teamList = db.getTeam();
//        adapterTeam = new AdapterTeam(teamList);
//        recyclerView.setAdapter(adapterTeam);

        ArrayList<HashMap<String,String>> row = db.getAllPlayerPosition2(Integer.parseInt(idteam2), posisih);

        for (int i=0; i <row.size(); i++){
            String id = row.get(i).get("id");
            String fullname = row.get(i).get("fullname");
            String nickname = row.get(i).get("nickname");
            String posisi = row.get(i).get("posisi");

            String nopunggung = row.get(i).get("nopunggung");
            String idteam = row.get(i).get("idteam");

            DataPlayer2 dataPlayer = new DataPlayer2();
            dataPlayer.setId(id);
            dataPlayer.setFullname(fullname);
            dataPlayer.setNickname(nickname);
            dataPlayer.setPosisi(posisi);

            dataPlayer.setNopunggung(nopunggung);
            dataPlayer.setIdteam(idteam);

            playerList2.add(dataPlayer);
        }

//        adapterPlayer = new AdapterPlayerPosition(playerList);
        adapterPlayer2 = new AdapterPlayerPosition2(GameActivity.this,playerList2);
        rccoba2.setAdapter(adapterPlayer2);
        adapterPlayer2.notifyDataSetChanged();

    }
*/
    @Override
    public void onBackPressed() {
        Intent i = new Intent(getApplicationContext(), GameChooseActivity.class);
        startActivity(i);
        finish();
    }

    @Override
    public void onClick(int i) {
        DataPlayerMatch curPlayer = cadanganAdapter1.getSelectedItem(i);
        fieldMode(editMode);
        curCadanganNo = curPlayer.getNopunggun();
        curCadanganNickname = curPlayer.getNickname();
        curCadanganTeam = idteam1;
        if (editMode.booleanValue()){
            runSnack("Silahkan pilih pemain yang ingin diganti.");
        }
    }

    @Override
    public void onClick2(int position) {
        DataPlayerMatch curPlayer = cadanganAdapter2.getSelectedItem(position);
        fieldMode(editMode);
        curCadanganNo = curPlayer.getNopunggun();
        curCadanganNickname = curPlayer.getNickname();
        curCadanganTeam = idteam2;
        if (editMode.booleanValue()) {
            runSnack("Silahkan pilih pemain yang ingin diganti.");
        }
    }

    private void runSnack(String s) {
        Snackbar.make(coordinatorLayout, (CharSequence) s,0).show();
    }

    public String getPositionName(Button btn) {
        int btnIndex = -1;
        Button[] listButton = new Button[]{btnLeft11, btnLeft21, btnLeft22, btnLeft23, btnLeft24, btnLeft31, btnLeft32, btnLeft33, btnLeft34, btnLeft41, btnLeft42, btnLeft43, btnLeft44, btnRight11, btnRight21, btnRight22, btnRight23, btnRight24, btnRight31, btnRight32, btnRight33, btnRight34, btnRight41, btnRight42, btnRight43, btnRight44};
        for (int i = 0; i < listButton.length; i++) {
            if (listButton[i] == btn) {
                btnIndex = i;
                break;
            }
        }
        String pos = "";
        if (btnIndex < listPosition.length) {
            return listPosition[btnIndex];
        }
        return listPosition[btnIndex - listPosition.length];
    }

    private void openPlayerOpt(String idteam, Button btn, TextView txt) {
    }


    public static String joinList(List list, String literal) {
        return list.toString().replaceAll(",", literal).replaceAll("[\\[.\\].\\s+]", "");
    }

    public void showCadanganBar(boolean s) {
        boolean z = true;
        if (s) {
            this.llCadangan.setLayoutParams(new LinearLayout.LayoutParams(-1, -2));
            if (this.boolMode == 1) {
                this.llField.setLayoutParams(new LinearLayout.LayoutParams(-1, (int) (((double) this.content_match.getHeight()) - this.hCadangan)));
            } else {
                this.llField.setLayoutParams(new LinearLayout.LayoutParams(-1, (int) (((double) getWindowManager().getDefaultDisplay().getWidth()) / 1.7d)));
            }
        } else {
            this.llCadangan.setLayoutParams(new LinearLayout.LayoutParams(-1, 0));
            if (this.boolMode == 1) {
                this.llField.setLayoutParams(new LinearLayout.LayoutParams(-1, (int) ((double) this.content_match.getHeight())));
            } else {
                this.llField.setLayoutParams(new LinearLayout.LayoutParams(-1, (int) (((double) getWindowManager().getDefaultDisplay().getWidth()) / 1.7d)));
            }
        }
        if (this.boolCadangan) {
            z = false;
        }
        this.boolCadangan = z;
    }

}
